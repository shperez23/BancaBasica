﻿using BPBancaBasica.DataAccess.Repository;
using BPBancaBasica.Entities;
using BPBancaBasica.Services.Operations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPBancaBasica.Business.Operations
{
    public class Movimientos: IMovimientos
    {
        public bool Actualizar(Movimiento Movimiento)
        {
            bool Result = false;
            if (Movimiento.MovimientoId != 0)
            {
                using (var Repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository())
                {
                    Result = Repository.Actualizar(Movimiento);
                }
            }
            return Result;
        }

        public List<Movimiento> Consultar(int id)
        {
            var Movimientos = BancaBasicaRepositoryFactory.GetBancaBasicaRepository().Consultar<Movimiento>();
            if (Movimientos != null)
            {
                Movimientos = (from x in Movimientos
                               where x.CuentaId == id
                           select x).ToList();
            }

            return Movimientos;
        }

        public Movimiento ConsultarPorId(int MovimientoID)
        {
            Movimiento Result = null;
            if (MovimientoID > 0)
            {
                using var Repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository();
                Result = Repository.ConsultarPorId<Movimiento>(MovimientoID);
            }

            return Result;
        }

        public bool Eliminar(int MovimientoID)
        {
            bool Result = false;
            if (MovimientoID > 0)
            {
                using (var Repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository())
                {
                    Result = Repository.Eliminar(new Movimiento { MovimientoId = MovimientoID });
                }
            }

            return Result;
        }

        public Movimiento Registrar(Movimiento Movimiento)
        {
            if (Movimiento.Valor!=0)
            {
                using var repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository();
                Movimiento = repository.Registrar(Movimiento);
            }
            else
            {
                Movimiento = null;
            }

            return Movimiento;
        }
    }
}
