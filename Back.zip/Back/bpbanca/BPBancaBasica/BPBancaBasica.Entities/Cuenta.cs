﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPBancaBasica.Entities
{
    public class Cuenta
    {

        public int CuentaId { get; set; }
        public int ClienteId { get; set; }
        public String Numero { get; set; }
        public Decimal Saldo { get; set; }

        public List<Movimiento> Movimientos { get; set; }

    }
}
