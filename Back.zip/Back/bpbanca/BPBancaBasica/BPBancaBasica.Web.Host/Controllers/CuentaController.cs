﻿using AutoMapper;
using BPBancaBasica.Services.Operations;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using BPBancaBasica.Entities;
using BPBancaBasica.Web.Host.ViewModel;
using Microsoft.AspNetCore.Authorization;
using BPBancaBasica.Web.Host.Policies;

namespace BPBancaBasica.Web.Host.Controllers
{

    [ApiController]
    public class CuentaController : ControllerBase
    {
        private readonly ICuentas _service;
        private readonly IMapper _mapper;

        public CuentaController(IMapper mapper, ICuentas Cuenta)
        {
            _service = Cuenta;
            _mapper = mapper;
        }


        // GET api/values
        [HttpGet("ConsultarCuenta", Name = "ConsultarCuenta")]
        [Authorize(Policy = RolePolicies.Admin)]
        public IEnumerable<CuentaViewModel> Consultar()
        {
            List<Cuenta> Cuentas = _service.Consultar();
            List<CuentaViewModel> Result = _mapper.Map<List<CuentaViewModel>>(Cuentas);

            return Result;

        }


        // GET api/values/5
        [HttpGet("ConsultarCuentaPorId/{id}")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<CuentaViewModel> ConsultarPorId(int id)
        {
            Cuenta Cuentas = _service.ConsultarPorId(id);
            CuentaViewModel Result = _mapper.Map<CuentaViewModel>(Cuentas);
            return Result;
        }

        // POST api/values
        [HttpPost("RegistrarCuenta")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<CuentaViewModel> RegistrarCuenta([FromBody] CuentaViewModel value)
        {

            CuentaViewModel Result;
            Cuenta Cuenta = _mapper.Map<Cuenta>(value);
            Cuenta = _service.Registrar(Cuenta);
            Result = _mapper.Map<CuentaViewModel>(Cuenta);

            return Result;
        }

        // PUT api/values/5
        [HttpPut("ActualizarCuenta")]
        [Authorize(Policy = RolePolicies.Cliente)]
        public ActionResult<bool> ActualizarCuenta([FromBody] CuentaViewModel value)
        {
            bool Result;
            Cuenta Cuenta = _mapper.Map<Cuenta>(value);
            Result = _service.Actualizar(Cuenta);

            return Result;

        }

        // DELETE api/values/5
        [HttpDelete("EliminarCuentaPorId/{id}")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<bool> EliminarCuentaPorId(int id)
        {
            bool Result;
            Result = _service.Eliminar(id);
            return Result;

        }


    }
}
