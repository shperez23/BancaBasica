﻿using System;

namespace BPBancaBasica.Web.Host.ViewModel
{
    public class MovimientoViewModel
    {
        public int MovimientoId { get; set; }
        public int CuentaId { get; set; }
        public int TipoMovimientoId { get; set; }
        public DateTime Fecha { get; set; }
        public Decimal Valor { get; set; }
        public Decimal Saldo { get; set; }

    }
}
