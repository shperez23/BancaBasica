﻿using System;

namespace BPBancaBasica.Web.Host.ViewModel
{
    public class TipoMovimientoViewModel
    {
        public int TipoMovimientoId { get; set; }
        public string Nombre { get; set; }

    }
}
