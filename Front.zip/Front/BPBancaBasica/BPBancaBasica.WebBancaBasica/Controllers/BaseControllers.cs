﻿using BPBancaBasica.WebBancaBasica.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace BPBancaBasica.WebBancaBasica.Controllers
{
    public class BaseControllers : Controller
    {
      

        public const string SSOUrl = "https://localhost:44300/";
        public const string ResourcesWebAPIUrl = "https://localhost:44301/";

        public async Task<(string ErrorMessage, string Token)> GetTokenAsync(UserCredentials userCredentials)
        {
            StringContent Content = new StringContent(JsonSerializer.Serialize(userCredentials), Encoding.UTF8, "application/json");

            (string ErrorMessage, string Token) Result = (null, null);
            var HttpClient = new HttpClient();
            var Response = await HttpClient.PostAsync($"{SSOUrl}login", Content);

            if (Response.IsSuccessStatusCode)
            {
                Result.Token = await Response.Content.ReadAsStringAsync();
            }
            else
            {
                Result.Token = null;
                Result.ErrorMessage = Response.ReasonPhrase;
            }

            return Result;
        }

        public async Task<string> GetDataAsync(string url, string token = null)
        {
            var HttpClient = new HttpClient();
            HttpResponseMessage Response;
            string ResultData = "";
            if (token != null)
            {
                // Enviar el Token como parte del encabezado de la petición
                HttpClient.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue(
                "bearer", token);
            }
            Response = await HttpClient.GetAsync(url);
            if (Response.IsSuccessStatusCode)
            {
                ResultData = await Response.Content.ReadAsStringAsync();
            }
            else
            {
                ResultData = Response.ReasonPhrase;
            }
            return ResultData;
        }

        public string GetClaimValue(string token, string claimType)
        {
            var Handler = new JwtSecurityTokenHandler();
            var Token = Handler.ReadJwtToken(token);
            return Token.Claims
            .Where(c => c.Type.Equals(claimType,
            StringComparison.OrdinalIgnoreCase))
            .Select(c => c.Value)
            .FirstOrDefault();
        }

        public string[] GetRoles(string token)
        {
            var Handler = new JwtSecurityTokenHandler();
            var Token = Handler.ReadJwtToken(token);
            var Roles = Token.Claims
            .Where(c => c.Type.Equals("role",
            StringComparison.OrdinalIgnoreCase))
            .Select(c => c.Value).ToArray();
            return Roles;
        }

        public string GetTokenFromSesssion()
        {
            return HttpContext.Session.GetString("ExpiryToken");
        }


        public async Task<T> SendPost<T, PostData>(string url, PostData data, string token)
        {
            T Result = default;
            using (var Client = new HttpClient())
            {
                try
                {
                   
                    Client.DefaultRequestHeaders.Accept.Clear();
                    Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("Application/json"));
                    var JSONData = Newtonsoft.Json.JsonConvert.SerializeObject(data);

                    if (token != null)
                    {
                        // Enviar el Token como parte del encabezado de la petición
                        Client.DefaultRequestHeaders.Authorization =
                        new System.Net.Http.Headers.AuthenticationHeaderValue(
                        "bearer", token);
                    }

                    HttpResponseMessage Response = await Client.PostAsync(url, new StringContent(JSONData.ToString(), Encoding.UTF8, "Application/json"));

                    var ResultWebApi = await Response.Content.ReadAsStringAsync();
                    Result = Newtonsoft.Json.JsonConvert.DeserializeObject<T>(ResultWebApi);
                }
                catch (Exception)
                {


                }
            }

            return Result;
        }

        public async Task<T> SendPut<T, PostData>(string url, PostData data, string token)
        {
            T Result = default;
            using (var Client = new HttpClient())
            {
                try
                {
                     
                    Client.DefaultRequestHeaders.Accept.Clear();
                    Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("Application/json"));
                    var JSONData = Newtonsoft.Json.JsonConvert.SerializeObject(data);

                    if (token != null)
                    {
                        // Enviar el Token como parte del encabezado de la petición
                        Client.DefaultRequestHeaders.Authorization =
                        new System.Net.Http.Headers.AuthenticationHeaderValue(
                        "bearer", token);
                    }

                    HttpResponseMessage Response = await Client.PutAsync(url, new StringContent(JSONData.ToString(), Encoding.UTF8, "Application/json"));

                    var ResultWebApi = await Response.Content.ReadAsStringAsync();
                    Result = Newtonsoft.Json.JsonConvert.DeserializeObject<T>(ResultWebApi);
                }
                catch (Exception)
                {


                }
            }

            return Result;
        }


        public async Task<T> SendGet<T>(string url, string token)
        {

            T Result = default;
            using (var Client = new HttpClient())
            {
                try
                {
                     
                    Client.DefaultRequestHeaders.Accept.Clear();
                    Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("Application/json"));

                    if (token != null)
                    {
                        // Enviar el Token como parte del encabezado de la petición
                        Client.DefaultRequestHeaders.Authorization =
                        new System.Net.Http.Headers.AuthenticationHeaderValue(
                        "bearer", token);
                    }

                    var ResultJson = await Client.GetStringAsync(url);
                    Result = Newtonsoft.Json.JsonConvert.DeserializeObject<T>(ResultJson);
                }
                catch (Exception ex)
                {


                }
            }

            return Result;
        }


        public async Task<T> SendDelete<T>(string url, string token)
        {

            T Result = default;
            using (var Client = new HttpClient())
            {
                try
                {

                    Client.DefaultRequestHeaders.Accept.Clear();
                    Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("Application/json"));

                    if (token != null)
                    {
                        // Enviar el Token como parte del encabezado de la petición
                        Client.DefaultRequestHeaders.Authorization =
                        new System.Net.Http.Headers.AuthenticationHeaderValue(
                        "bearer", token);
                    }

                    var ResultJson = await Client.DeleteAsync(url);
                    var responseContent = await ResultJson.Content.ReadAsStringAsync();

                    Result = Newtonsoft.Json.JsonConvert.DeserializeObject<T>(responseContent);
                }
                catch (Exception ex)
                {


                }
            }

            return Result;
        }



    }
}
