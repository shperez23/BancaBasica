﻿using BPBancaBasica.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPBancaBasica.Services.Operations
{
    public interface IClientes
    {
        Cliente Registrar(Cliente Cliente);
        bool Actualizar(Cliente Cliente);
        bool Eliminar(int ClienteID);
        Cliente ConsultarPorId(int ClienteID);
        List<Cliente> Consultar();

    }
}
