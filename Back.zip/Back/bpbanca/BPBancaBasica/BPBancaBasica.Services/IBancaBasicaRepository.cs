﻿using System;
using System.Collections.Generic;

namespace BPBancaBasica.Services
{
    public interface IBancaBasicaRepository : IDisposable
    {

        T Registrar<T>(T entity) where T : class;
        T ConsultarPorId<T>(params object[] keyValues) where T : class;

        bool Actualizar<T>(T entity) where T : class;
        bool Eliminar<T>(T entity) where T : class;
        List<T> Consultar<T>() where T : class;
        int GuardarCambios();


    }
}
