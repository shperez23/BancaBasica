﻿using System;

namespace EdDSAJwtBearer
{
    public class EdDSAKeys
    {
        public string Private { get; set; }
        public string Public { get; set; }

    }
}
