﻿using BPBancaBasica.WebBancaBasica.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BPBancaBasica.WebBancaBasica.Controllers
{
    public class MovimientoController : BaseControllers
    {
        //[HttpGet]
        //public async Task<IActionResult> Index()
        //{
        //    var Movimientos = new List<Movimiento>();

        //    var content = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarMovimiento",
        //           GetTokenFromSesssion());

        //    Movimientos = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Movimiento>>(content);

        //    return View(Movimientos);
        //}

        [HttpGet]
        public async Task<IActionResult> Registrar()
        {
            var movimiento = new Movimiento();
            movimiento.Fecha = DateTime.Now;
            var cuentas = new List<Cuenta>();
            var tipoMovimiento = new List<TipoMovimiento>();

            var content = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarCuenta",
                   GetTokenFromSesssion());
            cuentas = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Cuenta>>(content); 
            ViewBag.Cuentas = cuentas;


            var contentTipoMovimiento = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarTipoMovimiento",
                 GetTokenFromSesssion());
            tipoMovimiento = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TipoMovimiento>>(contentTipoMovimiento);
            ViewBag.TipoMovimiento = tipoMovimiento;


            ViewBag.isCreate = false;
            return View(movimiento);
        }


        [HttpPost]
        public async Task<IActionResult> Registrar(Movimiento Movimiento)
        {
            bool result = false;

            if (ModelState.IsValid)
            {
                Movimiento = await RegistrarMovimientoAsync($"{ResourcesWebAPIUrl}RegistrarMovimiento",
                    Movimiento, GetTokenFromSesssion());
                if (Movimiento.MovimientoId != 0)
                {
                    result = true;
                }
            }

            var cuentas = new List<Cuenta>();
            var tipoMovimiento = new List<TipoMovimiento>();

            var content = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarCuenta",
                   GetTokenFromSesssion());
            cuentas = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Cuenta>>(content);
            ViewBag.Cuentas = cuentas;


            var contentTipoMovimiento = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarTipoMovimiento",
                 GetTokenFromSesssion());
            tipoMovimiento = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TipoMovimiento>>(contentTipoMovimiento);
            ViewBag.TipoMovimiento = tipoMovimiento;



            ViewBag.isCreate = result;

            return View(Movimiento);
        }


        [HttpGet]
        public async Task<IActionResult> Actualizar(int id)
        {
            ViewBag.isUpdate = false;
            Movimiento Movimiento = await ConsultarMovimientoPorIdAsync($"{ResourcesWebAPIUrl}ConsultarMovimientoPorId",
                   id, GetTokenFromSesssion());

            var cuentas = new List<Cuenta>();
            var tipoMovimiento = new List<TipoMovimiento>();

            var content = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarCuenta",
                   GetTokenFromSesssion());
            cuentas = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Cuenta>>(content);
            ViewBag.Cuentas = cuentas;


            var contentTipoMovimiento = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarTipoMovimiento",
                 GetTokenFromSesssion());
            tipoMovimiento = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TipoMovimiento>>(contentTipoMovimiento);
            ViewBag.TipoMovimiento = tipoMovimiento;

           
            return View(Movimiento);
        }


        [HttpPost]
        public async Task<IActionResult> Actualizar(Movimiento Movimiento)
        {
            bool result = false;
            if (Movimiento.MovimientoId != 0)
            {
                result = await ActualizarMovimientoAsync($"{ResourcesWebAPIUrl}ActualizarMovimiento",
                    Movimiento, GetTokenFromSesssion());
            }

            var cuentas = new List<Cuenta>();
            var tipoMovimiento = new List<TipoMovimiento>();

            var content = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarCuenta",
                   GetTokenFromSesssion());
            cuentas = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Cuenta>>(content);
            ViewBag.Cuentas = cuentas;


            var contentTipoMovimiento = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarTipoMovimiento",
                 GetTokenFromSesssion());
            tipoMovimiento = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TipoMovimiento>>(contentTipoMovimiento);
            ViewBag.TipoMovimiento = tipoMovimiento;

            ViewBag.isUpdate = result;

            return View(Movimiento);
        }

         


        [HttpGet]
        public async Task<IActionResult> Eliminar(int id)
        {

            bool IsDelete = await EliminarMovimientoPorIdAsync($"{ResourcesWebAPIUrl}EliminarMovimientoPorId",
                    id, GetTokenFromSesssion());

            return RedirectToAction("Index");
        }




        public async Task<Movimiento> RegistrarMovimientoAsync(string url, Movimiento Movimiento, string token)
        {
            return await SendPost<Movimiento, Movimiento>(url, Movimiento, token);
        }

        public async Task<bool> ActualizarMovimientoAsync(string url, Movimiento Movimiento, string token)
        {
            return await SendPut<bool, Movimiento>(url, Movimiento, token);
        }

        public async Task<bool> EliminarMovimientoPorIdAsync(string url, int MovimientoID, string token)
        {
            return await SendDelete<bool>($"{url}/{MovimientoID}", token);
        }

        public async Task<Movimiento> ConsultarMovimientoPorIdAsync(string url, int MovimientoID, string token)
        {
            return await SendGet<Movimiento>($"{url}/{MovimientoID}", token);
        }

        public async Task<List<Movimiento>> ConsultarMovimientoPorCuentaIdAsync(string url, int CuentaID, string token)
        {
            return await SendGet<List<Movimiento>>($"{url}/{CuentaID}", token);
        }


        public async Task<List<TipoMovimiento>> ConsultarTipoMovimientoAsync(string url, string token)
        {
            return await SendGet<List<TipoMovimiento>>($"{url}", token);
        }


    }
}
