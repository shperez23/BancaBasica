﻿using BPBancaBasica.WebBancaBasica.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BPBancaBasica.WebBancaBasica.Controllers
{
    public class CuentaController : BaseControllers
    {
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var Cuentas = new List<Cuenta>();

            var content = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarCuenta",
                   GetTokenFromSesssion());
            if (content== "Forbidden")
            {
                ViewBag.RolValid = content;
                return View(Cuentas);
            }

            Cuentas = JsonConvert.DeserializeObject<List<Cuenta>>(content);

            return View(Cuentas);
        }

        [HttpGet]
        public async Task<IActionResult> Registrar()
        {
            var clientes = new List<Cliente>();

            var content = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarCliente",
                   GetTokenFromSesssion());
            clientes = JsonConvert.DeserializeObject<List<Cliente>>(content);

            ViewBag.Clientes = clientes;

            ViewBag.isCreate = false;
            return View(new Cuenta());
        }


        [HttpPost]
        public async Task<IActionResult> Registrar(Cuenta Cuenta)
        {
            bool result = false;

            if (ModelState.IsValid)
            {
                Cuenta = await RegistrarCuentaAsync($"{ResourcesWebAPIUrl}RegistrarCuenta",
                    Cuenta, GetTokenFromSesssion());
                if (Cuenta.CuentaId != 0)
                {
                    result = true;
                }
            }

            var clientes = new List<Cliente>(); 
            var content = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarCliente",
                   GetTokenFromSesssion());
            clientes = JsonConvert.DeserializeObject<List<Cliente>>(content);

            ViewBag.Clientes = clientes; 
            ViewBag.isCreate = result;

            return View(Cuenta);
        }


        [HttpGet]
        public async Task<IActionResult> Actualizar(int id)
        {
            ViewBag.isUpdate = false;
            Cuenta Cuenta = await ConsultarCuentaPorIdAsync($"{ResourcesWebAPIUrl}ConsultarCuentaPorId",
                   id, GetTokenFromSesssion());

            var clientes = new List<Cliente>();
            var content = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarCliente",
                   GetTokenFromSesssion());
            clientes = JsonConvert.DeserializeObject<List<Cliente>>(content);

            ViewBag.Clientes = clientes;



            return View(Cuenta);
        }


        [HttpPost]
        public async Task<IActionResult> Actualizar(Cuenta Cuenta)
        {
            bool result = false;
            if (Cuenta.CuentaId != 0)
            {
                result = await ActualizarCuentaAsync($"{ResourcesWebAPIUrl}ActualizarCuenta",
                    Cuenta, GetTokenFromSesssion());
            }

            var clientes = new List<Cliente>();
            var content = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarCliente",
                   GetTokenFromSesssion());
            clientes = JsonConvert.DeserializeObject<List<Cliente>>(content);

            ViewBag.Clientes = clientes; 
            ViewBag.isUpdate = result;

            return View(Cuenta);
        }


        [HttpGet]
        public async Task<IActionResult> Movimientos(int id)
        {
           
            var movimientos = new List<Movimiento>();

            movimientos = await ConsultarMovimientoPorCuentaIdAsync($"{ResourcesWebAPIUrl}ConsultarMovimiento",
                   id, GetTokenFromSesssion()); 
             
            return View(movimientos);
        }


         



        [HttpGet]
        public async Task<IActionResult> Eliminar(int id)
        {

            bool IsDelete = await EliminarCuentaPorIdAsync($"{ResourcesWebAPIUrl}EliminarCuentaPorId",
                    id, GetTokenFromSesssion());

            return RedirectToAction("Index");
        }




        public async Task<Cuenta> RegistrarCuentaAsync(string url, Cuenta Cuenta, string token)
        {
            return await SendPost<Cuenta, Cuenta>(url, Cuenta, token);
        }

        public async Task<bool> ActualizarCuentaAsync(string url, Cuenta Cuenta, string token)
        {
            return await SendPut<bool, Cuenta>(url, Cuenta, token);
        }

        public async Task<bool> EliminarCuentaPorIdAsync(string url, int CuentaID, string token)
        {
            return await SendDelete<bool>($"{url}/{CuentaID}", token);
        }

        public async Task<Cuenta> ConsultarCuentaPorIdAsync(string url, int CuentaID, string token)
        {
            return await SendGet<Cuenta>($"{url}/{CuentaID}", token);
        }

        public async Task<List<Movimiento>> ConsultarMovimientoPorCuentaIdAsync(string url, int CuentaID, string token)
        {
            return await SendGet<List<Movimiento>>($"{url}/{CuentaID}", token);
        }

    }
}
