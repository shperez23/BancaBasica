﻿using BPBancaBasica.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;

namespace BPBancaBasica.DataAccess
{
    public class BancaBasicaContext : DbContext
    {
        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Cuenta> Cuentas { get; set; }
        public DbSet<Movimiento> Movimientos { get; set; }
        public DbSet<TipoMovimiento> TipoMovimientos { get; set; }

         
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(Helper.HelperConfiguration.GetAppConfiguration().ConnectionString);
            }
        }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
          


            modelBuilder.Entity<Cliente>()
            .HasMany(b => b.Cuentas)
            .WithOne();

            modelBuilder.Entity<Cuenta>()
            .HasMany(b => b.Movimientos)
            .WithOne();

              


        }



    }
}
