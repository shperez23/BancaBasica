﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPBancaBasica.Helper
{
    public class HelperConfiguration
    {
        public static AppConfiguration GetAppConfiguration(string configurationFile = "appsettings.json")
        {

            IConfiguration Configuration = new ConfigurationBuilder()
                .AddJsonFile(configurationFile, optional: false)
                .Build();

            var Result = Configuration.Get<AppConfiguration>();

            return Result;


        }

    }
}
