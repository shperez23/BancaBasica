﻿using System;

namespace BPBancaBasica.Web.Host.ViewModel
{
    public class CuentaViewModel
    {
        public int CuentaId { get; set; }
        public int ClienteId { get; set; }
        public String Numero { get; set; }
        public Decimal Saldo { get; set; }

    }
}
