﻿using AutoMapper;
using BPBancaBasica.Services.Operations;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using BPBancaBasica.Entities;
using BPBancaBasica.Web.Host.ViewModel;
using Microsoft.AspNetCore.Authorization;
using BPBancaBasica.Web.Host.Policies;

namespace BPBancaBasica.Web.Host.Controllers
{

    [ApiController]
    public class TipoMovimientoController : ControllerBase
    {
        private readonly ITipoMovimientos _service;
        private readonly IMapper _mapper;

        public TipoMovimientoController(IMapper mapper, ITipoMovimientos TipoMovimiento)
        {
            _service = TipoMovimiento;
            _mapper = mapper;
        }


        // GET api/values
        [HttpGet("ConsultarTipoMovimiento", Name = "ConsultarTipoMovimiento")] 
        public IEnumerable<TipoMovimientoViewModel> Consultar()
        {
            List<TipoMovimiento> TipoMovimientos = _service.Consultar();
            List<TipoMovimientoViewModel> Result = _mapper.Map<List<TipoMovimientoViewModel>>(TipoMovimientos);

            return Result;

        }


        // GET api/values/5
        [HttpGet("ConsultarTipoMovimientoPorId/{id}")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<TipoMovimientoViewModel> ConsultarPorId(int id)
        {
            TipoMovimiento TipoMovimientos = _service.ConsultarPorId(id);
            TipoMovimientoViewModel Result = _mapper.Map<TipoMovimientoViewModel>(TipoMovimientos);
            return Result;
        }

        // POST api/values
        [HttpPost("RegistrarTipoMovimiento")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<TipoMovimientoViewModel> RegistrarTipoMovimiento([FromBody] TipoMovimientoViewModel value)
        {

            TipoMovimientoViewModel Result;
            TipoMovimiento TipoMovimiento = _mapper.Map<TipoMovimiento>(value);
            TipoMovimiento = _service.Registrar(TipoMovimiento);
            Result = _mapper.Map<TipoMovimientoViewModel>(TipoMovimiento);

            return Result;
        }

        // PUT api/values/5
        [HttpPut("ActualizarTipoMovimiento")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<bool> ActualizarTipoMovimiento([FromBody] TipoMovimientoViewModel value)
        {
            bool Result;
            TipoMovimiento TipoMovimiento = _mapper.Map<TipoMovimiento>(value);
            Result = _service.Actualizar(TipoMovimiento);

            return Result;

        }

        // DELETE api/values/5
        [HttpDelete("EliminarTipoMovimientoPorId/{id}")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<bool> EliminarTipoMovimientoPorId(int id)
        {
            bool Result;
            Result = _service.Eliminar(id);
            return Result;

        }


    }
}
