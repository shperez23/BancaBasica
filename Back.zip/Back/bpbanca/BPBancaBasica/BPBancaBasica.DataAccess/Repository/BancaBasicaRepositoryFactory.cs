﻿
using BPBancaBasica.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPBancaBasica.DataAccess.Repository
{
    public class BancaBasicaRepositoryFactory  
    {

        public static IBancaBasicaRepository GetBancaBasicaRepository(bool IsUnitOfWork = false)
        {
            return new BancaBasicaRepository(IsUnitOfWork);
        }

    }
}
