﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using EdDSAJwtBearer;
using Microsoft.AspNetCore.Mvc;
using SSOServer.Models;
using SSOServer.ViewModels;

namespace SSOServer.Controllers
{
    [ApiController]
    public class AccountController : ControllerBase
    {
        EdDSAJwtBearerServer Server;
        public AccountController(EdDSAJwtBearerServer server)
        {
            Server = server;
        }

        [HttpGet("login")]
        public IActionResult Login()
        {
            IActionResult Response = Unauthorized();
            Response = Ok("Iniciado");

            return Response;
        }



        [HttpPost("login")]
        public IActionResult Login([FromBody] UserCredentials credentials)
        {
            IActionResult Response = Unauthorized();
            var User = Repository.GetUser(credentials.Email, credentials.Password);
            if (User != null)
            {

                string Token = CreateToken(Server, User);
                Response = Ok(Token);
            }
            return Response;



        }

        private string CreateToken(EdDSAJwtBearerServer server, User user)
        {
            var Claims = new List<Claim>
                         {
                         new Claim("sub", user.Id.ToString()),
                         new Claim("firstName", user.FirstName),
                         new Claim("lastName", user.LastName),
                         new Claim("email", user.Email)
                         };

            //Puedes notar también que el Token expirará a los 30 minutos a partir de la fecha y hora actual pag 67.
            return server.CreateToken(Claims, user.Roles, DateTime.Now.AddMinutes(30));
        }

    }
}