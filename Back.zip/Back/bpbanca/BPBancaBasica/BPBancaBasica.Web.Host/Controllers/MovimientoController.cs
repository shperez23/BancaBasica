﻿using AutoMapper;
using BPBancaBasica.Services.Operations;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using BPBancaBasica.Entities;
using BPBancaBasica.Web.Host.ViewModel;
using Microsoft.AspNetCore.Authorization;
using BPBancaBasica.Web.Host.Policies;

namespace BPBancaBasica.Web.Host.Controllers
{

    [ApiController]
    public class MovimientoController : ControllerBase
    {
        private readonly IMovimientos _service;
        private readonly IMapper _mapper;

        public MovimientoController(IMapper mapper, IMovimientos Movimiento)
        {
            _service = Movimiento;
            _mapper = mapper;
        }


        // GET api/values
        [HttpGet("ConsultarMovimiento/{id}", Name = "ConsultarMovimiento")]
        [Authorize(Policy = RolePolicies.Admin)]
        public IEnumerable<MovimientoViewModel> Consultar(int id)
        {
            List<Movimiento> Movimientos = _service.Consultar(id);
            List<MovimientoViewModel> Result = _mapper.Map<List<MovimientoViewModel>>(Movimientos);

            return Result;

        }


        // GET api/values/5
        [HttpGet("ConsultarMovimientoPorId/{id}")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<MovimientoViewModel> ConsultarPorId(int id)
        {
            Movimiento Movimientos = _service.ConsultarPorId(id);
            MovimientoViewModel Result = _mapper.Map<MovimientoViewModel>(Movimientos);
            return Result;
        }

        // POST api/values
        [HttpPost("RegistrarMovimiento")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<MovimientoViewModel> RegistrarMovimiento([FromBody] MovimientoViewModel value)
        {

            MovimientoViewModel Result;
            Movimiento Movimiento = _mapper.Map<Movimiento>(value);
            Movimiento = _service.Registrar(Movimiento);
            Result = _mapper.Map<MovimientoViewModel>(Movimiento);

            return Result;
        }

        // PUT api/values/5
        [HttpPut("ActualizarMovimiento")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<bool> ActualizarMovimiento([FromBody] MovimientoViewModel value)
        {
            bool Result;
            Movimiento Movimiento = _mapper.Map<Movimiento>(value);
            Result = _service.Actualizar(Movimiento);

            return Result;

        }

        // DELETE api/values/5
        [HttpDelete("EliminarMovimientoPorId/{id}")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<bool> EliminarMovimientoPorId(int id)
        {
            bool Result;
            Result = _service.Eliminar(id);
            return Result;

        }


    }
}
