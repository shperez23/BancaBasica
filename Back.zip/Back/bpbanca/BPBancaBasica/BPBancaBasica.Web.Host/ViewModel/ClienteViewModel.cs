﻿namespace BPBancaBasica.Web.Host.ViewModel
{
    public class ClienteViewModel
    {

        public int ClienteId { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }

    }
}
