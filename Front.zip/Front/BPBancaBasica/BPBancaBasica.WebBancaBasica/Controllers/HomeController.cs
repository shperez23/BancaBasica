﻿using BPBancaBasica.WebBancaBasica.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace BPBancaBasica.WebBancaBasica.Controllers
{
    public class HomeController : BaseControllers
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IHttpClientFactory _clientFactory;

        public HomeController(ILogger<HomeController> logger, IHttpClientFactory clientFactory)
        {
            _logger = logger;
            _clientFactory = clientFactory;
        }

        [AllowAnonymous]
        public IActionResult Login()
        {
            return View(new IndexViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> Login(IndexViewModel data, string button)
        {
            var client = _clientFactory.CreateClient();


            switch (button)
            {
                case "login":
                    // Obtener el Token de acceso
                    (data.InformationMessage, data.Token) =
                    await GetTokenAsync(data.UserCredentials);
                    break; 
                case "getadmindata":
                    // Obtener los datos del rol Admin
                    data.InformationMessage =
                    await GetDataAsync($"{ResourcesWebAPIUrl}getadmindata",
                    data.Token);
                    break;
                case "getaccountantdata":
                    // Obtener los datos del rol Accountant
                    data.InformationMessage =
                    await GetDataAsync($"{ResourcesWebAPIUrl}getaccountantdata",
                    data.Token);
                    break;
                case "getsellerdata":
                    // Obtener los datos del rol Seller
                    data.InformationMessage =
                    await GetDataAsync($"{ResourcesWebAPIUrl}getsellerdata",
                    data.Token);
                    break;
            }

            if (data.Token != null)
            {
                data.FullUserName = $"{GetClaimValue(data.Token, "firstName")} {GetClaimValue(data.Token, "lastName")} ";
                data.Roles = GetRoles(data.Token);

                string roles = string.Empty;
                foreach (var item in data.Roles)
                {
                    roles = roles + "|" + item;
                }

                //var identity = new ClaimsIdentity(claim, CookieAuthenticationDefaults.AuthenticationScheme);
                //var principal = new ClaimsPrincipal(identity);
                //var props = new AuthenticationProperties();

                //HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, props).Wait();

                HttpContext.Session.SetString("FullUserName", data.FullUserName);
                HttpContext.Session.SetString("Roles", roles);
                HttpContext.Session.SetString("ExpiryToken", data.Token);
                 

            }

            return View(data);

        }



        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.SignOutAsync();
            HttpContext.Session.Clear();

            return RedirectToAction("Login");
        }

         

        

        




    }
}
