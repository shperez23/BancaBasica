﻿using BPBancaBasica.Business.Operations;
using BPBancaBasica.Services.Operations;
using System;

namespace BPBancaBasica.Business
{
    public class BancaBasicaOperationsFactory
    {
        public static IClientes GetClientesOperations()
        {
            return new Clientes();
        }

        public static ICuentas GetCuentasOperations()
        {
            return new Cuentas();
        }

        public static IMovimientos GetMovimientosOperations()
        {
            return new Movimientos();
        }

        public static ITipoMovimientos GetTipoMovimientosOperations()
        {
            return new TipoMovimientos();
        }


    }
}
