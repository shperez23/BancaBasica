﻿using AutoMapper;
using BPBancaBasica.Services.Operations;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using BPBancaBasica.Entities;
using BPBancaBasica.Web.Host.ViewModel;
using Microsoft.AspNetCore.Authorization;
using BPBancaBasica.Web.Host.Policies;

namespace BPBancaBasica.Web.Host.Controllers
{

    [ApiController]
    public class ClienteController : ControllerBase
    {
        private readonly IClientes _service;
        private readonly IMapper _mapper;

        public ClienteController(IMapper mapper, IClientes Cliente)
        {
            _service = Cliente;
            _mapper = mapper;
        }


        // GET api/values
        [HttpGet("ConsultarCliente", Name = "ConsultarCliente")]
        [Authorize(Policy = RolePolicies.Admin)]
        public IEnumerable<ClienteViewModel> Consultar()
        {
            List<Cliente> Clientes = _service.Consultar();
            List<ClienteViewModel> Result = _mapper.Map<List<ClienteViewModel>>(Clientes);

            return Result;

        }


        // GET api/values/5
        [HttpGet("ConsultarClientePorId/{id}")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<ClienteViewModel> ConsultarPorId(int id)
        {
            Cliente Clientes = _service.ConsultarPorId(id);
            ClienteViewModel Result = _mapper.Map<ClienteViewModel>(Clientes);
            return Result;
        }

        // POST api/values
        [HttpPost("RegistrarCliente")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<ClienteViewModel> RegistrarCliente([FromBody] ClienteViewModel value)
        {

            ClienteViewModel Result;
            Cliente Cliente = _mapper.Map<Cliente>(value);
            Cliente = _service.Registrar(Cliente);
            Result = _mapper.Map<ClienteViewModel>(Cliente);

            return Result;
        }

        // PUT api/values/5
        [HttpPut("ActualizarCliente")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<bool> ActualizarCliente([FromBody] ClienteViewModel value)
        {
            bool Result;
            Cliente Cliente = _mapper.Map<Cliente>(value);
            Result = _service.Actualizar(Cliente);

            return Result;

        }

        // DELETE api/values/5
        [HttpDelete("EliminarClientePorId/{id}")]
        [Authorize(Policy = RolePolicies.Admin)]
        public ActionResult<bool> EliminarClientePorId(int id)
        {
            bool Result;
            Result = _service.Eliminar(id);
            return Result;

        }


    }
}
