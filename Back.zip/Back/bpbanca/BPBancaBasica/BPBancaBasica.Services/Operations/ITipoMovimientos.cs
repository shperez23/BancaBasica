﻿using BPBancaBasica.Entities;
using System.Collections.Generic;

namespace BPBancaBasica.Services.Operations
{
    public interface ITipoMovimientos
    {
        TipoMovimiento Registrar(TipoMovimiento TipoMovimiento);
        bool Actualizar(TipoMovimiento TipoMovimiento);
        bool Eliminar(int TipoMovimientoID);
        TipoMovimiento ConsultarPorId(int TipoMovimientoID);
        List<TipoMovimiento> Consultar();

    }
}
