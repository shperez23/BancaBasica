﻿using Microsoft.AspNetCore.Authorization;

namespace BPBancaBasica.Web.Host.Policies
{
    public class RolePolicies
    {

        public const string Admin = "Admin";
        public const string Usuario = "Usuario";
        public const string Cliente = "Cliente";


        //política de autorización que requiera que un usuario esté autenticado
        //y pertenezca al rol Admin para poder acceder a un determinado recurso.

        public static AuthorizationPolicy AdminPolicy()
        {
            return new AuthorizationPolicyBuilder()
            .RequireAuthenticatedUser()
            .RequireRole(Admin)
            .Build();
        }

        // política de autorización que requiera que un usuario esté autenticado
        // y pertenezca al rol Accountant o Admin para poder acceder a un determinado recurso.

        public static AuthorizationPolicy UsuarioPolicy()
        {
            return new AuthorizationPolicyBuilder()
            .RequireAuthenticatedUser()
            .RequireRole(Usuario, Admin)
            .Build();
        }


        //a política de autorización que requiera que un usuario esté autenticado
        //y pertenezca al rol Seller o Admin para poder acceder a un determinado recurso.

        public static AuthorizationPolicy ClientePolicy()
        {
            return new AuthorizationPolicyBuilder()
            .RequireAuthenticatedUser()
            .RequireRole(Cliente, Admin)
            .Build();
        }


    }
}
