using BPBancaBasica.Business;
using BPBancaBasica.Services.Operations;
using BPBancaBasica.Web.Host.Policies;
using EdDSAJwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using static EdDSAJwtBearer.EdDSAJwtBearerAuthenticationHandler;

namespace BPBancaBasica.Web.Host
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAutoMapper(typeof(Startup));
            services.AddControllers();


            //para registrar el esquema de autenticaci�n personalizado
            services.AddAuthentication(
                 EdDSAJwtBearerDefaults.AuthenticationScheme)
                 .AddEdDSAJwtBearer(options =>
                 {
                     Configuration.Bind("JWT", options);
                 });

            //Registrar el servicio de pol�ticas de autorizaci�n
            services.AddAuthorization(options =>
            {
                options.AddPolicy(RolePolicies.Admin,
                RolePolicies.AdminPolicy());
                options.AddPolicy(RolePolicies.Cliente,
                RolePolicies.ClientePolicy());
                options.AddPolicy(RolePolicies.Usuario,
                RolePolicies.UsuarioPolicy());
            });

            //pol�tica CORS que acepte peticiones de cualquier origen, cualquier encabezado y cualquier m�todo.
            services.AddCors(options =>
            {
                options.AddPolicy("default", builder =>
                {
                    //builder.WithOrigins(
                    //        // App:CorsOrigins in appsettings.json can contain more than one address separated by comma.
                    //        Configuration["App:CorsOrigins"]ik
                    //            .Split(",", StringSplitOptions.RemoveEmptyEntries) 
                    //            .ToArray()
                    //);

                    builder.AllowAnyOrigin();
                    builder.AllowAnyHeader();
                    builder.AllowAnyMethod();
                });
            });

            services.AddSingleton(typeof(IClientes),
         F => BancaBasicaOperationsFactory.GetClientesOperations());

            services.AddSingleton(typeof(ICuentas),
            F => BancaBasicaOperationsFactory.GetCuentasOperations());

            services.AddSingleton(typeof(IMovimientos),
            F => BancaBasicaOperationsFactory.GetMovimientosOperations());

            services.AddSingleton(typeof(ITipoMovimientos),
          F => BancaBasicaOperationsFactory.GetTipoMovimientosOperations());


            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "BPBancaBasica", Version = "v1" });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "BPBancaBasica.Web.Host v1"));
            }

            app.UseHttpsRedirection();

            app.UseRouting();
            app.UseCors("default");
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers().RequireCors("default");
            });
        }
    }
}
