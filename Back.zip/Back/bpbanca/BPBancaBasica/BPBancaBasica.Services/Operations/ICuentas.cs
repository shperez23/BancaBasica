﻿using BPBancaBasica.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPBancaBasica.Services.Operations
{
    public interface ICuentas
    {
        Cuenta Registrar(Cuenta Cuenta);
        bool Actualizar(Cuenta Cuenta);
        bool Eliminar(int CuentaID);
        Cuenta ConsultarPorId(int CuentaID);
        List<Cuenta> Consultar();

    }
}
