﻿using BPBancaBasica.DataAccess.Repository;
using BPBancaBasica.Entities;
using BPBancaBasica.Services.Operations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPBancaBasica.Business.Operations
{
    public class Cuentas: ICuentas
    {
        public bool Actualizar(Cuenta Cuenta)
        {
            bool Result = false;
            if (Cuenta.CuentaId != 0)
            {
                using (var Repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository())
                {
                    Result = Repository.Actualizar(Cuenta);
                }
            }
            return Result;
        }

        public List<Cuenta> Consultar()
        {
            var Cuentas = BancaBasicaRepositoryFactory.GetBancaBasicaRepository().Consultar<Cuenta>();
            if (Cuentas != null)
            {
                Cuentas = (from x in Cuentas
                            select x).ToList();
            }

            return Cuentas;
        }

        public Cuenta ConsultarPorId(int CuentaID)
        {
            Cuenta Result = null;
            if (CuentaID > 0)
            {
                using var Repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository();
                Result = Repository.ConsultarPorId<Cuenta>(CuentaID);
            }

            return Result;
        }

        public bool Eliminar(int CuentaID)
        {
            bool Result = false;
            if (CuentaID > 0)
            {
                using (var Repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository())
                {
                    Result = Repository.Eliminar(new Cuenta { CuentaId = CuentaID });
                }
            }

            return Result;
        }

        public Cuenta Registrar(Cuenta Cuenta)
        {
            if (!string.IsNullOrEmpty(Cuenta.Numero))
            {
                using var repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository();
                Cuenta = repository.Registrar(Cuenta);
            }
            else
            {
                Cuenta = null;
            }

            return Cuenta;
        }
    }
}
