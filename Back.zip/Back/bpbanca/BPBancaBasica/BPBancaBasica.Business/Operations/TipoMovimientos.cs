﻿using BPBancaBasica.DataAccess.Repository;
using BPBancaBasica.Entities;
using BPBancaBasica.Services.Operations;
using System.Collections.Generic;
using System.Linq;

namespace BPBancaBasica.Business.Operations
{
    public class TipoMovimientos: ITipoMovimientos
    {
        public bool Actualizar(TipoMovimiento TipoMovimiento)
        {
            bool Result = false;
            if (TipoMovimiento.TipoMovimientoId != 0)
            {
                using (var Repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository())
                {
                    Result = Repository.Actualizar(TipoMovimiento);
                }
            }
            return Result;
        }

        public List<TipoMovimiento> Consultar()
        {
            var TipoMovimientos = BancaBasicaRepositoryFactory.GetBancaBasicaRepository().Consultar<TipoMovimiento>();
            if (TipoMovimientos != null)
            {
                TipoMovimientos = (from x in TipoMovimientos
                             select x).ToList();
            }

            return TipoMovimientos;
        }

        public TipoMovimiento ConsultarPorId(int TipoMovimientoID)
        {
            TipoMovimiento Result = null;
            if (TipoMovimientoID > 0)
            {
                using var Repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository();
                Result = Repository.ConsultarPorId<TipoMovimiento>(TipoMovimientoID);
            }

            return Result;
        }

        public bool Eliminar(int TipoMovimientoID)
        {
            bool Result = false;
            if (TipoMovimientoID > 0)
            {
                using (var Repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository())
                {
                    Result = Repository.Eliminar(new TipoMovimiento { TipoMovimientoId = TipoMovimientoID });
                }
            }

            return Result;
        }

        public TipoMovimiento Registrar(TipoMovimiento TipoMovimiento)
        {
            if (!string.IsNullOrEmpty(TipoMovimiento.Nombre))
            {
                using var repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository();
                TipoMovimiento = repository.Registrar(TipoMovimiento);
            }
            else
            {
                TipoMovimiento = null;
            }

            return TipoMovimiento;
        }
    }
}
