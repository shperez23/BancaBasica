﻿using AutoMapper;
using BPBancaBasica.Entities;
using BPBancaBasica.Web.Host.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BPBancaBasica.Web.Host.Profiles
{
    public class ConfigureProfiles : Profile
    {
        public ConfigureProfiles()
        {

            CreateMap<Cliente, ClienteViewModel>();
            CreateMap<ClienteViewModel, Cliente>();
            CreateMap<Cuenta, CuentaViewModel>();
            CreateMap<CuentaViewModel, Cuenta>();
            CreateMap<Movimiento, MovimientoViewModel>();
            CreateMap<MovimientoViewModel, Movimiento>();

            CreateMap<TipoMovimiento, TipoMovimientoViewModel>();
            CreateMap<TipoMovimientoViewModel, TipoMovimiento>();
        }
    }
}
