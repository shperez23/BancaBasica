﻿using BPBancaBasica.WebBancaBasica.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BPBancaBasica.WebBancaBasica.Controllers
{
    public class ClienteController : BaseControllers
    {
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var clientes = new List<Cliente>();

            var content = await GetDataAsync($"{ResourcesWebAPIUrl}ConsultarCliente",
                   GetTokenFromSesssion());

            if (content == "Forbidden")
            {
                ViewBag.RolValid = content;
                return View(clientes);
            }

            clientes = JsonConvert.DeserializeObject<List<Cliente>>(content);

            return View(clientes);
        }

        [HttpGet]
        public IActionResult Registrar()
        {
            ViewBag.isCreate = false;
            return View(new Cliente());
        }


        [HttpPost]
        public async Task<IActionResult> Registrar(Cliente cliente)
        {
            bool result = false;

            if (ModelState.IsValid)
            {
                cliente = await RegistrarClienteAsync($"{ResourcesWebAPIUrl}RegistrarCliente", 
                    cliente, GetTokenFromSesssion());
                if (cliente.ClienteId!=0)
                {
                    result = true;
                }
            }

            ViewBag.isCreate = result;

            return View(cliente);
        }


        [HttpGet]
        public async Task<IActionResult> Actualizar(int id)
        {
            ViewBag.isUpdate = false;
            Cliente cliente = await ConsultarClientePorIdAsync($"{ResourcesWebAPIUrl}ConsultarClientePorId",
                   id, GetTokenFromSesssion());
             
            return View(cliente);
        }


        [HttpPost]
        public async Task<IActionResult> Actualizar(Cliente cliente)
        {
            bool result = false;
            if (cliente.ClienteId!=0)
            {
                result = await ActualizarClienteAsync($"{ResourcesWebAPIUrl}ActualizarCliente",
                    cliente, GetTokenFromSesssion());
            }

            ViewBag.isUpdate = result;

            return View(cliente);
        }


        [HttpGet]
        public async Task<IActionResult> Eliminar(int id)
        {

            bool IsDelete = await EliminarClientePorIdAsync($"{ResourcesWebAPIUrl}EliminarClientePorId",
                    id, GetTokenFromSesssion());

            return RedirectToAction("Index");
        }




        public async Task<Cliente> RegistrarClienteAsync(string url, Cliente cliente, string token)
        {
            return await SendPost<Cliente, Cliente>(url, cliente, token);
        }

        public async Task<bool> ActualizarClienteAsync(string url, Cliente cliente, string token)
        {
            return await SendPut<bool, Cliente>(url, cliente, token);
        }
         
        public async Task<bool> EliminarClientePorIdAsync(string url, int clienteID, string token)
        {
            return await SendDelete<bool>($"{url}/{clienteID}", token);
        }
         
        public async Task<Cliente> ConsultarClientePorIdAsync(string url, int clienteID, string token)
        {
            return await SendGet<Cliente>($"{url}/{clienteID}", token);
        }

    }
}
