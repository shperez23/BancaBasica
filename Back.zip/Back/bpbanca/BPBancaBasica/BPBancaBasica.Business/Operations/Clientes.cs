﻿using BPBancaBasica.DataAccess.Repository;
using BPBancaBasica.Entities;
using BPBancaBasica.Services.Operations;
using System.Collections.Generic;
using System.Linq;

namespace BPBancaBasica.Business.Operations
{
    public class Clientes: IClientes
    {
        public bool Actualizar(Cliente Cliente)
        {
            bool Result = false;
            if (Cliente.ClienteId != 0)
            {
                using (var Repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository())
                {
                    Result = Repository.Actualizar(Cliente);
                }
            }
            return Result;
        }

        public List<Cliente> Consultar()
        {
            var Clientes = BancaBasicaRepositoryFactory.GetBancaBasicaRepository().Consultar<Cliente>();
            if (Clientes != null)
            {
                Clientes = (from x in Clientes
                             select x).ToList();
            }

            return Clientes;
        }

        public Cliente ConsultarPorId(int ClienteID)
        {
            Cliente Result = null;
            if (ClienteID > 0)
            {
                using var Repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository();
                Result = Repository.ConsultarPorId<Cliente>(ClienteID);
            }

            return Result;
        }

        public bool Eliminar(int ClienteID)
        {
            bool Result = false;
            if (ClienteID > 0)
            {
                using (var Repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository())
                {
                    Result = Repository.Eliminar(new Cliente { ClienteId = ClienteID });
                }
            }

            return Result;
        }

        public Cliente Registrar(Cliente Cliente)
        {
            if (!string.IsNullOrEmpty(Cliente.Nombre))
            {
                using var repository = BancaBasicaRepositoryFactory.GetBancaBasicaRepository();
                Cliente = repository.Registrar(Cliente);
            }
            else
            {
                Cliente = null;
            }

            return Cliente;
        }
    }
}
