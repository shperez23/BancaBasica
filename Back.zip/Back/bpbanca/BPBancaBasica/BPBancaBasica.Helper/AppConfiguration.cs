﻿using System;

namespace BPBancaBasica.Helper
{
    public class AppConfiguration
    {
        public string ConnectionString { get; set; }
    }
}
